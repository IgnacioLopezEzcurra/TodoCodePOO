
package Logica;

public interface IFuego {
    
    public void atacarPunioFuego();
    public void atacarLanzallamas();
    public void atacarAscuas();
    
}
