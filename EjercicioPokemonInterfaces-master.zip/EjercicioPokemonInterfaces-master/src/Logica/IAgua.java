
package Logica;


public interface IAgua {
    
    public void atacarHidrobomba();
    public void atacarBurbuja();
    public void atacarPistolaAgua();
    
}
