
package Logica;


public interface IElectrico {
    
    public void atacarImpactrueno();
    public void atacarPunioTrueno();
    
}
