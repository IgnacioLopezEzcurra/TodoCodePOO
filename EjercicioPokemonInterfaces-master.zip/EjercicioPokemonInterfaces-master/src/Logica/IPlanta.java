
package Logica;


public interface IPlanta {
    
    public void atacarDrenaje();
    public void atacarParalizar();
    
}
